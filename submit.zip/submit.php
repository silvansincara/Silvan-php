<?php


$host="localhost";
$username="root";
$password="";
$dbname="database";



try{


$db=new PDO("mysql:host=$host;dbname=$dbname",$username,$dbname);


$db=setAttribute(PDO::ATTR_ERRMODE,PDO::ERRMODE_EXCEPTION);

$QUERY="INSERT INTO BLABLA(First,Middle,Last,Birthday,Citizenship,nationality,nationality,Identification,Studies,gender,Education,others,img,Language,Religious,affiliation,postal,code,Town,pcountry,Mobile,email)  
  VALUES  (':First,Middle',:Last,:,Birthday,:nationality,:nationality,:Identification,:Studies,:gender,:Education,:others,:img,:Language,:Religious,:affiliation,:postal,:code,:Town,:pcountry,:Mobile,:email)";

$stmt=$db->prepare($QUERY);
$stmt->bindParam('First',$First);
$stmt->bindParam('Middle',$Middle);
$stmt->bindParam(',Last',$,Last);
$stmt->bindParam('Birthday',$Birthday);
$stmt->bindParam('Citizenship',$Citizenship);
$stmt->bindParam('nationality',$nationality);
$stmt->bindParam('Identification',$Identification);
$stmt->bindParam('Studies',$Studies);                      
$stmt->bindParam('gender',$gender);
$stmt->bindParam('Education',$Education);
$stmt->bindParam('others',$others);
$stmt->bindParam('img',$img);
$stmt->bindParam('Religious',$Religious);
$stmt->bindParam('affiliation',$affiliation);
$stmt->bindParam('postal',$,postal);
$stmt->bindParam('code',$code);
$stmt->bindParam('Town',$Town);
$stmt->bindParam('pcountry',$pcountry);
$stmt->bindParam('Mobile',$Mobile);
$stmt->bindParam('email',$email);
$stmt->bindParam('Lastname',$Lastname);



$Firstname=$_POST['Firstname'];
$Lastname=$_POST['Lastname'];
$Lastname=$_POST['Lastname'];
$Lastname=$_POST['Lastname'];
$Lastname=$_POST['Lastname'];
$Lastname=$_POST['Lastname'];
$Lastname=$_POST['Lastname'];
$Lastname=$_POST['Lastname'];
$Lastname=$_POST['Lastname'];
$Lastname=$_POST['Lastname'];
$Lastname=$_POST['Lastname'];
$Lastname=$_POST['Lastname'];
$Lastname=$_POST['Lastname'];
$Lastname=$_POST['Lastname'];
$Lastname=$_POST['Lastname'];
$Lastname=$_POST['Lastname'];
$Lastname=$_POST['Lastname'];
$Lastname=$_POST['Lastname'];
$Lastname=$_POST['Lastname'];
$Lastname=$_POST['Lastname'];
$Lastname=$_POST['Lastname'];
$Lastname=$_POST['Lastname'];

$stmt->execute();

echo "Inserted succesfully";



}catch(PDOException e){


    echo  "Connection failed" .$e->getMessage();
}
















?>